export interface FindOperator {
  skip?: number;
  where?: {};
  include?: {};
}
