export const prismaMock = {
  user: {},
};
